# Project Images Placeholder

Add your project images here with the following names:
- ecommerce.jpg
- task-api.jpg
- ml-platform.jpg
- chat-app.jpg
- devops-toolkit.jpg

Recommended size: 1200x675px (16:9 aspect ratio)
Formats: JPG, PNG, or WebP

Until you add images, the projects will display with gradient backgrounds.
