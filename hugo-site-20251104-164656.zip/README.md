# Hugo Blog with Noir Theme

A beautiful, minimalistic blog built with Hugo and the hugo-noir theme. This site features dark/light mode, responsive design, and a clean aesthetic perfect for blogging and showcasing your work.

## 🚀 Quick Start

### Prerequisites

- Hugo Extended (v0.92.0 or newer) - [Install Hugo](https://gohugo.io/installation/)
- Git

### Installation

1. **Clone this repository**
   ```bash
   git clone <your-repo-url>
   cd Hugo-Site
   ```

2. **Initialize the theme submodule**
   ```bash
   git submodule update --init --recursive
   ```

3. **Start the development server**
   ```bash
   hugo server -D
   ```

4. **Open your browser**
   Navigate to `http://localhost:1313` to see your site!

## 📝 Adding Content

### Creating a New Blog Post

The easiest way to add a blog post:

```bash
hugo new content/en/blogs/my-new-post.md
```

This creates a new file at `content/en/blogs/my-new-post.md` with front matter. Edit the file and add your content:

```markdown
---
title: "My New Blog Post"
date: 2024-11-04T10:00:00-08:00
draft: false
tags: ["tag1", "tag2"]
categories: ["category"]
description: "A brief description of your post"
---

Your content here...
```

**Important**: Set `draft: false` when you're ready to publish!

### Creating a New Project

Add a new project to showcase your work:

```bash
hugo new content/en/projects/my-project.md
```

Edit the file with your project details:

```markdown
---
title: "My Awesome Project"
date: 2024-11-04T10:00:00-08:00
draft: false
tags: ["react", "nodejs"]
description: "Description of your project"
github: "https://github.com/yourusername/project"
demo: "https://demo.example.com"
---

# Project Description

Details about your project...

## Features
- Feature 1
- Feature 2

## Tech Stack
- Technology 1
- Technology 2
```

### Adding Static Pages

To add or edit static pages like About, Contact, etc., edit the corresponding files in `content/en/`:

- `content/en/about.md` - About page
- `content/en/contact.md` - Contact page
- `content/en/experience.md` - Experience page (uses data from `data/en/experience.toml`)

## ⚙️ Configuration

### Site Configuration

Edit `hugo.toml` to customize your site:

```toml
baseURL = "https://yourdomain.com/"
title = "Your Blog Title"
theme = "hugo-noir"

[params]
  name = "Your Name"
  location = "Your Location"
  description = "Your description"
  profile_image = "/images/profile.jpg"
  
  # Social links
  github = "https://github.com/yourusername"
  twitter = "https://twitter.com/yourusername"
  linkedin = "https://linkedin.com/in/yourusername"
  email = "your.email@example.com"
```

### Personal Information

Edit these data files to customize your site content:

#### Author Information (`data/en/author.toml`)
```toml
[author]
name = "Your Name"
location = "Your City, Country"
description = "Your bio..."
profile_image = "/images/profile.jpg"

# Social links
github = "https://github.com/yourusername"
twitter = "https://twitter.com/yourusername"
linkedin = "https://linkedin.com/in/yourusername"
email = "your.email@example.com"
```

#### Tech Stack (`data/en/tech.toml`)

Customize the tech stack carousel displayed on your site. Icons come from [Devicon](https://devicon.dev/).

```toml
row1 = [
  { icon = "devicon-python-plain", name = "Python" },
  { icon = "devicon-javascript-plain", name = "JavaScript" },
  # Add more technologies...
]

row2 = [
  { icon = "devicon-docker-plain", name = "Docker" },
  { icon = "devicon-postgresql-plain", name = "PostgreSQL" },
  # Add more technologies...
]
```

Find more icon names at [devicon.dev](https://devicon.dev/).

#### Experience (`data/en/experience.toml`)

Add your work experience:

```toml
[[experience]]
role = "Job Title"
company = "Company Name"
company_link = "https://company.com"  # Optional
period = "Jan 2020 - Present"
country = "Country"
responsibilities = [
  "Responsibility 1",
  "Responsibility 2",
  "Responsibility 3"
]
technologies = ["Tech1", "Tech2", "Tech3"]
```

### Navigation Menu

Edit the menu in `hugo.toml`:

```toml
[languages.en.menu]
  [[languages.en.menu.main]]
    name = "Menu Item"
    pageRef = "/page-path"
    weight = 1  # Lower numbers appear first
```

## 🎨 Customization

### Adding Your Profile Picture

1. Add your profile picture to `static/images/profile.jpg`
2. Update the path in `hugo.toml` and `data/en/author.toml`

### Custom CSS

Create `assets/css/custom.css` to add your own styles:

```css
/* Your custom styles */
.custom-class {
    color: #your-color;
}
```

## 📁 Project Structure

```
Hugo-Site/
├── content/
│   └── en/              # English content
│       ├── _index.md    # Homepage
│       ├── about.md     # About page
│       ├── contact.md   # Contact page
│       ├── experience.md # Experience page
│       ├── blogs/       # Blog posts
│       └── projects/    # Project pages
├── data/
│   └── en/              # Site data
│       ├── author.toml  # Author info
│       ├── tech.toml    # Tech stack
│       └── experience.toml # Work experience
├── static/              # Static assets
│   ├── images/          # Images
│   ├── css/            # Custom CSS
│   └── js/             # Custom JavaScript
├── themes/
│   └── hugo-noir/      # Theme files (don't edit)
└── hugo.toml           # Site configuration
```

## 🚢 Deployment

### Build Your Site

```bash
hugo
```

This generates your static site in the `public/` directory.

### Deploy Options

- **GitHub Pages**: Push to GitHub and enable GitHub Pages
- **Netlify**: Connect your repo and deploy automatically
- **Vercel**: Import your repository and deploy
- **AWS S3**: Upload the `public/` folder to S3

### Example: Deploy to GitHub Pages

1. Create a GitHub repository
2. Add this to `hugo.toml`:
   ```toml
   baseURL = "https://yourusername.github.io/repo-name/"
   ```
3. Build and push:
   ```bash
   hugo
   git add .
   git commit -m "Deploy site"
   git push origin main
   ```

## 📚 Resources

- [Hugo Documentation](https://gohugo.io/documentation/)
- [Hugo Noir Theme](https://github.com/prxshetty/hugo-noir)
- [Markdown Guide](https://www.markdownguide.org/)
- [Devicon Icons](https://devicon.dev/)

## 🎯 Tips for Content Creation

1. **Keep drafts**: Use `draft: true` while working on posts
2. **Use tags and categories**: Help readers find related content
3. **Add descriptions**: Improve SEO and social sharing
4. **Use code blocks**: Triple backticks with language for syntax highlighting
5. **Add images**: Place in `static/images/` and reference as `/images/filename.jpg`
6. **Preview locally**: Always check with `hugo server -D` before publishing

## 🐛 Troubleshooting

### Site not loading after changes?

```bash
# Clear Hugo cache
hugo --gc
# Restart server
hugo server -D
```

### Theme not working?

```bash
# Update theme
git submodule update --remote --merge
```

### Port already in use?

```bash
# Use a different port
hugo server -D -p 1314
```

## 📄 License

This project uses the Hugo Noir theme, which is licensed under the MIT License.

## 🤝 Contributing

Feel free to customize this blog for your needs! If you make improvements, consider contributing back to the [hugo-noir theme](https://github.com/prxshetty/hugo-noir).

---

**Happy Blogging! 🎉**

For questions or issues, please open an issue on the theme repository or refer to the Hugo documentation.
