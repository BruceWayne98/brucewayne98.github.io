---
title: "About"
date: 2024-11-04T10:00:00-08:00
draft: false
layout: "about"
---

Hello! I'm a software engineer with a passion for building elegant solutions to complex problems. With several years of experience in full-stack development, I've worked on everything from scalable backend systems to beautiful user interfaces.

## What I Do

I specialize in:
- **Backend Development**: Building robust APIs and microservices
- **DevOps**: Implementing CI/CD pipelines and cloud infrastructure

## My Journey

My journey in software development started with curiosity and has evolved into a career I'm passionate about. I believe in continuous learning, clean code, and building software that makes a difference.

## Beyond Code

When I'm not coding, you'll find me:
- Reading tech blogs and staying up-to-date with industry trends
- Contributing to open-source projects
- Writing about my experiences and learnings
- Exploring new technologies and frameworks
