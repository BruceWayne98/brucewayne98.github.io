---
title: "Experience"
date: 2024-11-04T10:00:00-08:00
draft: false
layout: "experience"
---

My professional journey in software development, showcasing the roles, responsibilities, and technologies I've worked with throughout my career.
