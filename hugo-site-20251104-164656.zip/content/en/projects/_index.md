---
title: "Projects"
date: 2024-11-04T10:00:00-08:00
draft: false
---

Here are some of the projects I've worked on. Each project represents a unique challenge and learning opportunity.
